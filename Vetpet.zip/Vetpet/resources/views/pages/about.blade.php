@extends('layouts.layout')

<link rel="stylesheet" href="{{ asset('css/about.css') }}">

@section('content')



<div class="row opis">
    <div class="col-xl-6 col-md-6 mb-4 prvi">
    <div class="col-xl-6 col-md-6 mb-4">
        <div class="card border-0 shadow">
          <img src="images/about/prva.jpg" class="card-img-top" alt="...">
        </div>
      </div>
    </div>
    <div class="col-lg-6">
    Vetpet je specijalizovana maloprodaja hrane i opreme za sve kućne ljubimce, prisutan u Srbiji od 2008. godine kada je na Novom Beogradu otvorena prva Vetpet prodavnica u Srbiji.

Danas regionalni lider, Vetpet je započeo sa radom daleke 1999. godine, sa željom da postane mesto najšire ponude asortimana za kućne ljubimce.

Od tih početaka puno se promenilo: višestruko je proširen asortiman, prodavnice su veće i prilagođene najvišim standardima moderne maloprodaje, izradili smo vlastitu robnu marku hrane za pse i mačke koja pruža najbolji odnos cene i kvalitete na tržištu, te konstantno radimo na unapređenju ponude i osiguranju najboljih cena za naše kupce.

Posebno smo posvećeni postizanju najviših standarda kvaliteta usluge, na čemu stalno radimo u želji da nadmašimo očekivanja naših kupaca. U okviru svih Vetpet prodavnica rade i veterinarske apoteke u kojima uvek možete dobiti i stručan savet nekog od naših veterinara, a snabdevanje robom je automatizovano i strogo se kontroliše, kako biste uvek pronašli onaj artikal po koji ste došli. Vetpet nudi kompletan asortiman hrane i opreme za sve kućne ljubimce, kao i bogatu ponudu malih životinja (ptice i glodari), akvaristike i teraristike. Sve životinje iz Pet centra imaju veterinarsku potvrdu i dokaz porekla od registrovanih odgajivača iz Srbije i sveta.

Danas je Vetpet prepoznat kao vodeća specijalizovana maloprodaja za kućne ljubimce u regiji, sa kvalitetom ponude i usluge na nivou najboljih specijalizovanih maloprodaja u Evropi. U Srbiji Vetpet zapošljava oko 100 ljudi i ima osam prodajna objekta: u Beogradu, na Karaburmi, Zemunu, Rakovici, Novom Sadu, Nišu, Kragujevcu i Čačku. Regionalno Vetpet je prisutan u Hrvatskoj i u Rumuniji gde posluje pod imenom Maxi Pet.

Svih 350 zaposlenih u Vetpet grupi, u tri zemlje i 20 prodajnih mesta ljubitelji su, a najčešće i vlasnici životinja.

Naša misija je uneti radost u živote kućnih ljubimaca i njihovih vlasnika, promovisati prednosti suživota ljudi i životinja, te edukovati široku javnost i konstantno promovisati dobrobit životinja.

Zahvaljujemo našim kupcima na ukazanom poverenju i nadamo se da ćemo ga i u budućnosti opravdati, a ako do sada niste imali prilike posetiti neku od naših prodavnica, pozivamo Vas da svakako dođete zajedno sa svojim ljubimcem.
<br><br>
Vaš Vetpet
<br><br>
Ljubimci znaju zašto.
    </div>
</div>


  
</div>


@endsection
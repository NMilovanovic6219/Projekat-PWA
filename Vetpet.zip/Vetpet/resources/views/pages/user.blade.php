@extends('layouts.layout')

<link rel="stylesheet" href="{{ asset('css/user.css') }}">

@section('content')

<div class="container mt-5">
    <div class="row">

        <div class="user-info col-lg-12">
            @if ($user->type == 'admin')
                <h1>Admin: {{ $user->username }}</h1>
            @elseif ($user->type == 'editor')
                <h1>Editor: {{ $user->username }}</h1>
            @else
                <h1>Username: {{ $user->username }}</h1>
            @endif
            <p>Email: {{ $user->email }}</p>
            

            <a class="edit-user-icon" href="{{ route('editUser', ['id' => $user->userID]) }}">
                <p>Izmeni</p>
            </a>
        </div>

    </div>
    
    

            <div class="container nesto1">
                <div class="row">
                    <div>
                        <h1>Porudžbine</h1>
                        <table>
                            <tr>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Kolicina</td>
                                <td class="nesto">Cena</td>
                            </tr>
                        @foreach ($orders as $o)
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $o->naziv }}</p></td>
                                <td class="nesto"><p>{{ $o->amount }}</p></td>
                                <td class="nesto"><p>{{ $o->amount * $o->cena }}</p></td>
                            </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
</div>
            

<script src="js/adminSearch.js"></script>

@endsection
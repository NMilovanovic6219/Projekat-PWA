@extends('layouts.layout')

<link rel="stylesheet" href="{{ asset('css/contact.css') }}">

@section('content')

<section class="section pb-5">

  
    <div class="row">
  
      <div class="col-lg-5 mb-4">

        <form action="" method="POST">
          @csrf
          <div class="card">
  
            <div class="card-body">
              <div class="form-header blue accent-1">
                <h3> Pisite nam:</h3>
              </div>
    
              
              <br>

              <div class="md-form">
                 
                  <input type="text" class="form-control" placeholder="Vase ime" name="ime" value="{{ old('ime') }}">
              </div>
              @error('ime')
                <p style="color: #FF5145">{{ $message }}</p>
              @enderror
    
              <div class="md-form">
                
                <input type="email" class="form-control" placeholder="Email" name="email" value="{{ old('email') }}">
              </div>
              @error('email')
                <p style="color: #FF5145">{{ $message }}</p>
              @enderror
    
              <div class="md-form">
                
                <input type="text" class="form-control" placeholder="Naslov poruke" name="naslov" value="{{ old('naslov') }}">
              </div>
              @error('naslov')
                <p style="color: #FF5145">{{ $message }}</p>
              @enderror
    
              <div class="md-form">
                
                <textarea name="tekst" class="form-control md-textarea" rows="3" placeholder="Tekst poruke" value="{{ old('tekst') }}"></textarea>
              </div>
              @error('tekst')
                <p style="color: #FF5145">{{ $message }}</p>
              @enderror
    
              <div class="text-center mt-4">
                <button type="submit" class="btn submit">Posalji</button>
              </div>
            </div>
    
          </div>
        </form>
  
      </div>

      
  
    </div>
  
</section>

@endsection
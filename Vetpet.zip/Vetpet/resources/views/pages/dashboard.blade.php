@extends('layouts.layout')

<link rel="stylesheet" href="{{ asset('css/dashboard.css') }}">

@section('content')



<div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Korisnici</h1>
                        <table>
                            <tr>
                                <td class="nesto">Username</td>
                                <td class="nesto">Email</td>
                                <td class="nesto">Tip</td>
                                <td class="nesto">Created at:</td>
                                <td class="nesto">Updated at:</td>
                            </tr>
                        @foreach ($users as $u)
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $u->username }}</p></td>
                                <td class="nesto"><p>{{ $u->email }}</p></td>
                                <td class="nesto"><p>{{ $u->type }}</p></td>
                                <td class="nesto"><p>{{ $u->created_at }}</p></td>
                                <td class="nesto"><p>{{ $u->updated_at }}</p>
                                @if (auth()->user()->type === 'admin')
                                <div class="u-icons">
                                    <a href="{{ route('editUser', [
                                        'id' => $u->userID
                                    ]) }}">
                                        <p>Edituj</p>
                                    </a>

                                    <a href="{{ route('deleteUser', [
                                        
                                        'id' => $u->userID
                                    ]) }}">
                                        <p>Obriši</p>
                                    </a>
                            
                                </div>
                            @endif
                            </td>
                            </tr>
                            @endforeach
                        </table>
                    </div>

                           
                              
                        </div>
                    
                
            </div>
            </div> 
            </div>
            </div>
           
            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Proizvodi</h1>
                        <table>
                            <tr>
                                <td class="nesto">Naziv</td>
                                <td class="nesto">Cena</td>
                                <td class="nesto">Na stanju</td>
                                <td class="nesto">Opis</td>
                                
                            </tr>
                            @foreach ($products as $p)
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $p->naziv }}</p></td>
                                <td class="nesto"><p>{{ $p->cena }}</p></td>
                                <td class="nesto"><p>{{ $p->naStanju }}</p></td>
                                <td class="nesto"><p>{{ $p->opis }}</p>
                                <div class="p-icons">
                                <a href="{{ route('editProduct', [
                                    'id' => $p->productID
                                ]) }}">
                                    <p>Edituj</p>
                                </a>
                                
                                @if (auth()->user()->type === 'admin')
                                    <a href="{{ route('deleteProduct', [
                                        'id' => $p->productID
                                    ]) }}">
                                    <p>Obriši</p>
                                    </a>
                                @endif</td>
                                
                                
                            </tr>
                            
                            @endforeach

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div>   
            </div>
            </div>                          


            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Poridzbine</h1>
                        <table>
                            <tr>
                                <td class="nesto">Username</td>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Cena</td>
                                
                            </tr>
                            @foreach ($orders as $o)
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $o->username }}</p></td>
                                <td class="nesto"><p>{{ $o->amount }}</p></td>
                                <td class="nesto"><p>{{ $o->amount * $o->cena }}</p>
                                @if (auth()->user()->type === 'admin')
                                        <a href="{{ route('deleteOrder', ['id' => $o->orderID]) }}">
                                            <p>Obrisi</p>
                                        </a>
                                    @endif</td>
                                
                                
                                
                            </tr>
                            
                            
                            @endforeach

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>





            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Poruke</h1>
                        <table>
                            <tr>
                                <td class="nesto">Naslov</td>
                                <td class="nesto">Status</td>
                                <td class="nesto">Ime</td>
                                <td class="nesto">Email</td>
                                <td class="nesto">Poruka</td>
                                
                            </tr>
                            @foreach ($messages as $m)
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $m->naslov }}</p></td>
                                <td class="nesto"><p>{{ $m->status }}</p></td>
                                <td class="nesto"><p>{{ $m->ime }}</p></td>
                                <td class="nesto"><p>{{ $m->email }}</p></td>
                                <td class="nesto"><p>{{ $m->tekst }}</p> 
                                @if (auth()->user()->type === 'admin')
                                    <a href="{{ route('deleteMessage', ['id' => $m->messageID]) }}">
                                        <p>Obriši</p>
                                    </a>
                                @endif    
                            </td>
                                
                            </tr>
                            
                            
                            @endforeach

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>



            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Srca</h1>
                        <table>
                            <tr>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Korisnik</td>
                                
                            </tr>
                            @foreach ($likes as $l)
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $l->naziv }}</p></td>
                                <td class="nesto"><p>{{ $l->username }}</p>
                                @if (auth()->user()->type === 'admin')
                                    <a href="{{ route('deleteLike', ['id' => $l->likeID]) }}">
                                    <p>Obriši</p>
                                    </a>
                                @endif
                            </td>
                                
                                
                            </tr>
                            
                            
                            @endforeach

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>



            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Komentari</h1>
                        <table>
                            <tr>
                                <td class="nesto">Korisnik</td>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Tekst</td>
                                
                            </tr>
                            @foreach ($comments as $c)
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user">{{ $c->username }}</p></td>
                                <td class="nesto"><p>{{ $c->naziv }}</p></td>
                                <td class="nesto"><p>{{ $c->tekst }}</p>
                                @if (auth()->user()->type === 'admin')
                                    <a href="{{ route('deleteComment', ['id' => $c->commentID]) }}">
                                    <p>Obriši</p>
                                    </a>
                                @endif
                            </td>
                               
                            
                                
                                
                            </tr>
                            
                            
                            @endforeach

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>

           




    

        <div class="row">
            <div class="col" id="chart_div"></div>
        </div>
    </div>
</div>



<script src="js/adminSearch.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    const chartInfo = {!! json_encode($orders->toArray()) !!}

    const productsArr = []
    const newArr = []

    chartInfo.forEach(el => {
        productsArr.push([el.naziv, el.amount])
        newArr.push(el.naziv)
    })

    let s = new Set(newArr);
    let setValues = Array.from(s.values());

    const arr = []
    for(let i = 0; i < setValues.length; i++) {
        let num = 0

        for(let j = 0; j < productsArr.length; j++) {
            if(productsArr[j][0] === setValues[i]) {
                num += productsArr[j][1]
                
                productsArr.splice(j, 1)
            }
        }

        arr.push([setValues[i], num])
    }

    // Load the Visualization API and the corechart package.
    google.charts.load('current', {'packages':['corechart']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawChart);

    // Callback that creates and populates a data table,
    // instantiates the pie chart, passes in the data and
    // draws it.
    function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', '');
        data.addRows(arr);

        const height = data.getNumberOfRows() * 81 + 30;
        // Set chart options
        var options = {'title':'Sold Products',
                        'width': '100%',
                        'height': height};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(data, options);
    }
</script>



@endsection
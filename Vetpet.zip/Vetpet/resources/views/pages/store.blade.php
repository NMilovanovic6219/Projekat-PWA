@extends('layouts.layout')
<link rel="stylesheet" href="{{ asset('css/store.css') }}">

@section('content')

<div class="container">
    <div class="row">
        @foreach ($products as $p)
            <div class="card col-lg-3 col-md-6 text-center" >
                <img class="card-img-top" src="{{ $p->img }}" alt="Nije do nas">
                <div class="card-body">
                  <h4 class="card-title">{{ $p->naziv }}</h4>
                  <p class="card-text">Cena: {{ $p->cena }}din</p>
                  <a href="{{ route('product', ['id' => $p->productID]) }}" 
                  class="s-product-btn btn btn-primary">Vidi proizvod</a>
                </div>
            </div>
        @endforeach
    </div>  
</div>

@endsection
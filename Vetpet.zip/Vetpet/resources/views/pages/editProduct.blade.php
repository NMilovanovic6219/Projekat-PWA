@extends('layouts.layout')

<link rel="stylesheet" href="{{ asset('css/product-edit.css') }}">

@section('content')

    <h1>
        
        {{ $product->naziv }}
    </h1>

<div class="container">
    <div class="row">
        <form class="m-5 form" action="" method="POST">
            @csrf

            <input name="id" type="hidden" value="{{ $product->productID }}">

            <label>
                <p style="margin: 0 !important">Naziv:</p>
                
                <input name="naziv" type="text" value="{{ $product->naziv }}">
            </label>

            <label>
                <p style="margin: 0 !important">Cena:</p>
                
                <input name="cena" type="number" value="{{ $product->cena }}">
            </label>

            
            <label>
                <p style="margin: 0 !important">Na stanju:</p>
                
                <input name="naStanju" type="number" value="{{ $product->naStanju }}">
            </label>

            <label>
                <p style="margin: 0 !important">Slika proizvoda:</p>
                
                <input name="img" type="text" value="{{ $product->img }}">
            </label>

                
            <textarea name="opis" rows="10" cols="50" class="p-3">{{ $product->opis }}</textarea>

            <button class="mt-3" type="submit">Izmeni</button>
        </form>
    </div>
</div>

@endsection
-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2021 at 09:51 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vetpet`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` bigint(20) UNSIGNED NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `productID` int(11) DEFAULT NULL,
  `tekst` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `userID`, `productID`, `tekst`, `created_at`, `updated_at`) VALUES
(34, 18, 1, 'Dje se kupas', '2021-07-13 18:09:44', '2021-07-13 18:09:44'),
(35, 21, 2, 'Moja kuca nece da jede ovo, stvarno uzas', '2021-07-14 05:50:00', '2021-07-14 05:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `likeID` bigint(20) UNSIGNED NOT NULL,
  `userID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`likeID`, `userID`, `productID`, `created_at`, `updated_at`) VALUES
(39, 21, 22, '2021-06-05 22:47:09', '2021-06-05 22:47:09'),
(40, 21, 20, '2021-06-05 22:48:20', '2021-06-05 22:48:20'),
(41, 14, 13, '2021-06-05 22:52:03', '2021-06-05 22:52:03'),
(42, 14, 15, '2021-06-05 22:52:12', '2021-06-05 22:52:12'),
(43, 14, 4, '2021-06-05 22:52:18', '2021-06-05 22:52:18'),
(44, 14, 17, '2021-06-05 22:52:58', '2021-06-05 22:52:58'),
(45, 14, 22, '2021-06-05 22:53:23', '2021-06-05 22:53:23'),
(46, 22, 4, '2021-06-07 13:13:48', '2021-06-07 13:13:48'),
(47, 7, 5, '2021-06-07 15:23:55', '2021-06-07 15:23:55'),
(48, 18, 1, '2021-07-13 18:09:08', '2021-07-13 18:09:08'),
(49, 18, 14, '2021-07-14 05:46:28', '2021-07-14 05:46:28'),
(50, 23, 10, '2021-07-14 05:47:08', '2021-07-14 05:47:08'),
(51, 23, 19, '2021-07-14 05:47:13', '2021-07-14 05:47:13'),
(52, 21, 13, '2021-07-14 05:49:11', '2021-07-14 05:49:11'),
(53, 21, 17, '2021-07-14 05:51:14', '2021-07-14 05:51:14'),
(54, 21, 34, '2021-07-14 05:51:29', '2021-07-14 05:51:29');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` bigint(20) UNSIGNED NOT NULL,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `naslov` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tekst` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Neprocitano'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `ime`, `email`, `naslov`, `tekst`, `created_at`, `updated_at`, `status`) VALUES
(17, 'Nikola', 'nikola@gmail.com', 'Primedba', 'Moram da primetim da vam je sajt jako ruzan', '2021-07-14 05:48:13', '2021-07-14 05:48:13', 'Neprocitano'),
(18, 'Nikolina', 'nina@gmail.com', 'Pohvala', 'Jako sam zahvalna uslugom i kvalitetom.', '2021-07-14 05:51:06', '2021-07-14 05:51:06', 'Neprocitano');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` bigint(20) UNSIGNED NOT NULL,
  `userID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `userID`, `productID`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(39, 28, 4, 1, 'Pending', '2021-07-14 05:06:51', '2021-07-14 05:06:51'),
(40, 28, 4, 1, 'Pending', '2021-07-14 05:29:52', '2021-07-14 05:29:52'),
(41, 28, 4, 1, 'Pending', '2021-07-14 05:30:58', '2021-07-14 05:30:58'),
(42, 18, 1, 1, 'Pending', '2021-07-14 05:45:55', '2021-07-14 05:45:55'),
(43, 18, 14, 1, 'Pending', '2021-07-14 05:46:11', '2021-07-14 05:46:11'),
(44, 18, 14, 1, 'Pending', '2021-07-14 05:46:36', '2021-07-14 05:46:36'),
(45, 23, 10, 1, 'Pending', '2021-07-14 05:47:06', '2021-07-14 05:47:06'),
(46, 23, 19, 1, 'Pending', '2021-07-14 05:47:16', '2021-07-14 05:47:16'),
(47, 23, 33, 5, 'Pending', '2021-07-14 05:47:31', '2021-07-14 05:47:31'),
(48, 21, 13, 5, 'Pending', '2021-07-14 05:49:09', '2021-07-14 05:49:09');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cena` double DEFAULT NULL,
  `naStanju` int(11) DEFAULT NULL,
  `opis` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `naziv`, `cena`, `naStanju`, `opis`, `img`) VALUES
(1, 'WOLFPACK Black Angus govedina, hladno presovana hrana za pse\r\n', 1390, 15, 'WOLFPACK Hladno presovana hrana s govedinom Black Angus - najbolje iz prirode!\r\nPotpuna hrana za pse svih uzrasta i rasa\r\n\r\nZasnovana na principima ishrane pasa i vukova kao što je u njihovom prirodnom staništu, gde odrasli dele svoj obrok sa mladuncima.\r\n\r\nŠta je proces hladnog presovanja?\r\nNakon mešanja, fino samleveni sastojci presovanjem se oblikuju u pelete bez podvrgavanja visokim temperaturama.\r\nNiska temperatura obezbeđuje očuvanje osnovnih hranljivih materija, posebno onih koji u sebi s', 'images/proizvodi/prva.jpg'),
(2, 'ASPECT West Highland White Terrier, s piletinom i pirinčem', 950, 5, 'ASPECT West Highland White Terrier\r\n\r\nPotpuna hrana za pse, s piletinom i pirinčem\r\n\r\nSastav: otkošćeno pileće meso (23%), pirinač (20%), pileće mesno brašno (16%), pirinčane mekinje, pileća mast, sušeni repini rezanci, kvasac, hidrolizovani životinjski proteini, laneno seme (2%), glukozamin sulfat (0,02%), koren cikorije (izvor mananoligosaharida (0,018%)), biljna mešavina (0,02% - komorač, bosiljak, žalfija), voćni oligosaharidi - FOS (0,012%), hondroitin sulfat (0,012%), ekstrakt Yucca schidi', 'images/proizvodi/druga.jpg'),
(3, 'REMI Piletina i pirinač, potpuna hrana za pse', 590, 12, 'REMI Potpuna hrana za odrasle pse, sa piletinom i pirinčem\r\n\r\nREMI receptura sa pažljivo odabranim kvalitetnim sastojcima potpun je i lako svarljiv dnevni obrok, izvrstan za svakog psa.\r\n\r\nSastav: dehidrirano meso, kukuruz, pšenica, prerađevine biljnog porekla, dehidrirana piletina (8%), pirinač (4%), pileća mast, minerali.\r\n\r\nAnalitički sastav: sirovi proteini 23%, sirove masti 9%, sirova vlakna 3,5%, sirovi pepeo 10%.\r\nDodaci: nutritivni dodaci/kg: vitamin A 10000 IJ, vitamin D3 750 IJ, vitami', ' images/proizvodi/treca.jpg'),
(4, 'ALLEVA HOLISTIC Adult s jagnjetinom i divljači, Medium/Maxi, bez žitarica', 2490, 2, 'HOLISTIC Jagnjetina&Divljač, sa kanabidiolom iz industrijske konoplje i ženšenom\r\n\r\nPotpuna hrana za odrasle pse srednjih i velikih rasa.\r\n\r\nSASTAV: dehidrirana jagnjetina (35%), otkošćeno jagnjeće meso (20%), dehidrirano meso jelena (15%), slatki krompir, pileća mast, skrob iz graška,vlakna iz graška, riblje ulje, pileća džigerica, koren cikorije (izvor inulina i F.O.S.-a), psilijum (indijska bokvica), osušeni pivski kvasac (izvor M.O.S.-a), natrijum karbonat, glukozamin, hondroitin sulfat, Can', 'images/proizvodi/cetvrta.jpg'),
(5, 'ASPECT Maltese, s piletinom i pirinčem, 1kg', 990, 15, 'ASPECT Maltese\r\n\r\nPotpuna hrana za pse, s piletinom i pirinčem\r\n\r\nSastav: otkošćeno pileće meso (23%), pirinač (20%), pileće mesno brašno 16%, pirinčane mekinje, pileća mast, sušeni repini rezanci, kvasac, hidrolizovani životinjski proteini, laneno seme (2%), glukozamin sulfat (0,02%), koren cikorije (izvor mananoligosaharida (0,018%)), biljna mešavina (0,02% - komorač, bosiljak, žalfija), voćni oligosaharidi - FOS (0,012%), hondroitin sulfat (0,012%), ekstrakt Yucca schidigera (0,01%), ekstrakt', 'images/proizvodi/peta.jpg'),
(10, 'WOLFPACK Jagnjetina, bez žitarica', 239, 30, 'WOLFPACK Jagnjetina\r\nPotpuna hrana za odrasle pse, bez žitarica\r\n\r\nSASTAV: jagnjetina (srca, jetra, meso, škembići) 66%, bujon 28,7%, bundeva 2%, brusnica 2%, mineralne materije 1%, laneno ulje 0,2%, mešavina suvog bilja (ruzmarin, bosiljak, timijan, origano, kamilica, maslačak, lovorov list, peršun, žalfija, korijander, kopar) 0,1%.\r\n\r\nANALITIČKI SASTAV: sirovi proteini 10,50%, sirove masti 7,80%, sirovi pepeo 3%, sirova vlakna 0,30%, vlaga 75,00%.\r\n\r\nDODACI: Nutritivni dodaci/kg: vitamin D3 (3', 'images/proizvodi/sesta.jpg'),
(11, 'BRIT CARE Mini kesica, fileti u sosu s divljači, 85g', 115, 4, 'BRIT CARE Mini kesica, fileti u sosu s divljači\r\nPotpuna hrana za odrasle sterilisane pse malih rasa\r\n\r\nKomadići fileta od mesa u ukusnom sosu nude potpunu i balansiranu prehranu za mini i male rase.\r\n\r\nSASTAV: meso i prerađevine životinjskog porekla u filetima 85% (meso divljači 8%), mesni sos 9,6%, začinsko bilje i voće (karanfilić, agrumi, ruzmarin, kurkuma) 1,5%, borovnice 0,5%, mineralne materije 1%, lososovo ulje 1%, manan oligosaharidi 0,5%, voćni oligosaharidi 0,5%, inulin 0,4%.\r\n\r\nANALI', 'images/proizvodi/sedma.jpg'),
(12, 'ANIMAL-FARM Treats&Snacks Poslastica za pse Piletina i Banana 80g', 450, 12, 'Poslastica sa bananom i pilećim mesom.\r\nPoslastica za pse\r\nDopunska hrana za pse, bez konzervanasa\r\n\r\nSASTOJCI: meso i proizvodi životinjskog porekla (od čega 63,5% minimum od piletine), voće (banana 30%), ulja i masti, šećeri i minerali..\r\n\r\nANALITIČKI SASTAV: sirovi proteini 27,9%, sirova ulja i masti 14,1%, sirovi pepeo 2,4%, sirova vlakna 0,3%, vlaga 11,9%.\r\n\r\nUPUTSTVO ZA UPOTREBU I ČUVANJE: namenjeno je psima starosti preko 4 meseca.\r\nDati 2-12 poslastica dnevno u zavisnosti od veličine psa', 'images/proizvodi/osma.jpg'),
(13, 'CLAN Briketi za pse Medium/Maxi Jagnjetina 15kg', 3150, 8, 'CLAN MEDIUM LAMB\r\nPotpuna hrana za odrasle pse srednjih rasa starosti preko 12 meseci\r\n\r\nClan Medium Lamb je hrana za pse bogata proteinima koji održavaju mišićni tonus. Prisustvo glukozamina i hondroitin sulfata u hrani štiti zglobove, dok FOS stimuše rad lakto bakterija creva, omega 3 masne kiseline hrane kožu i čine dlaku sjajnom.\r\n\r\nSASTOJCI: piletina (14%) dehidrirana jagnjetina ((8%), kukuruz, pirinač, pileća mast, suvi repini rezanci, ekstrakt pilećih proteina, kalcijum fosfat, natrijum h', 'images/proizvodi/deveta.jpg'),
(14, 'BRIT CARE Mini PUPPY, s jagnjetinom, bez žitarica', 470, 15, 'Brit Care Mini Grain Free - Puppy, s jagnjetinom\r\n\r\nHipoalergijska formula bez žitarica za štence mini rasa (od 2 nedelje do 10 meseci) i njihove majke.\r\nKompletna hrana za pse\r\n\r\nSastav: brašno od jagnjetine (35%), proteini iz sveže jagnjetine (20%), žuti grašak, pileća mast (konzervisana tokoferolima), leblebija, seme lana (5%), lososovo ulje (3%), heljda, sušene jabuke, pivski kvasac, alge (0,5%, Ascophyllum nodosum), sušene ljuske školjki (izvor glukozamina, 290 mg/kg), borovnica (250 mg/kg,', 'images/proizvodi/deseta.jpg'),
(15, 'LANDFLEISCH Goveđa srca s pirinčem, u pašteti', 179, 11, 'Dr. Alder Landfleisch sa Goveđim srcima i Pirinčem proizvedeno od svežeg mesa i povrća.\r\n\r\nPotpuna hrana za odrasle pse sa biotinom, inulinom i Omega 3+6.\r\n\r\nSastav: meso i mesne prerađevine 67% (goveđa srca 20%), goveđa supa 21%, pirinač 5%, povrće (šargarepa, grašak) 5%, mineralna hraniva, biljna ulja (omega 3+6 masne kiselina), inulin 0,1%.\r\nAnaliza: vlaga 78,0%, sirovi proteini 10,5%, sirove masti 6,5%, sirov pepeo 2,6%, sirova vlakna 0,6%.\r\nIzrađeno po proizvođačkoj specifikaciji.\r\nDodaci /', 'images/proizvodi/jedanaesta.jpg'),
(16, 'CAMON Transporter Skudo, za avio transport IATA', 7290, 2, 'Transporteri Skudo za srednje i velike pse.\r\n\r\nMetalna vrata sa dvostrukom kontrolnom sigurnosnom bravom.\r\n\r\nC190/4 je za pse maksimalne telesne mase 30 kg.\r\nC190/5 je za pse maksimalne telesne mase 35kg.\r\nC190/6 je za pse maksimalne telesne mase 40 kg.\r\nC190/7 je za pse maksimalne telesne mase 45 kg.\r\n\r\nIma pregradu za dokumenta (jednu kod C190 / 4 verzije, dve kod verzija C190 / 5, C190 / 6 i C190 / 7).\r\nOdgovara IATA zahtevima za prevoz živih životinja.\r\nNa spoju izmedju gornjeg i donjeg dela', 'images/proizvodi/dvan.jpg'),
(17, 'Von BARF Adriatic, sirova zamrznuta hrana za pse, 10x250g', 2190, 11, 'VON BARF ADRIATIC\r\nZamrznuta sirova hrana za pse\r\n\r\nZamrznuta, biološki usklađena sirova hrana za pse sa sardinom i govedinom uz dodatak mediteranskih biljaka. Potpuni obrok koji preporučujemo davati jednom nedeljno, kako bi se optimizirala količina omega 3 masnih kiselina u ishrani vašeg psa\r\n\r\nBez konzervansa, veštačkih boja, pojačivača ukusa, pesticida\r\nBez žitarica i skroba.\r\nJadranska sardina kvalitetna je sitna plava riba bogata omega-3 kiselinama i biotinom.\r\nKost je optimalan izvor miner', 'images/proizvodi/trin.jpg'),
(18, 'BRIT PREMIUM by Nature JUNIOR Large Breeds', 990, 9, 'Brit Premium by Nature Junior L\r\nPotpuna hrana s piletinom za mlade pse (1-24 meseci) velikih rasa (25-45 kg).\r\n\r\nSASTAV: piletina 45 % (dehidrirana 25 %, otkošćena 20 %), zob, pšenica, pileća mast (konzervisana mešanim tokoferolima), kukuruz, lososovo ulje (2 %), sušene jabuke, hidrolizovana pileća jetra, pivski kvasac, kolagen, oklopi račića (izvor glukozamina, 260 mg/kg), hrskavice (izvor hondroitina, 180 mg/kg), bilja i voća (karanfilić, citrusi, ruzmarin, kurkuma, 150 mg/kg), manan-oligosah', 'images/proizvodi/cetr.jpg'),
(19, 'RUSTICAN Piletina s lososom i pirinčem, bez glutena', 1690, 13, 'RUSTICAN Piletina sa lososom i pirinčem\r\nPotpuna hrana za odrasle pse\r\n\r\nUkusna receptura sa izobiljem visokosvarljivih proteina i esencijalnih masnih kiselina. Osvežavajući svakodnevni obrok i idealna letnja ishrana. Takođe, izvrsna za pse preosetljive na crveno meso. Savršena fuzija mekane piletine i lososa, upotpunjena integralnim pirinčem bez glutena, obogaćena prirodnim sokovima brusnice i crne ribizle. Pojačana sočnim jabukama, slatkom šargarepom i brašnom morskih rakova.\r\n\r\nSASTAV: dehidr', 'images/proizvodi/petn.jpg'),
(20, 'CANAGAN Dental, ćuretina i piletina, za pse, bez žitarica', 2490, 11, 'CANAGAN Dental\r\n\r\nPotpuna hrana bez žitarica za pse svih starosnih kategorija.\r\nĆuretina iz slobodnog uzgoja, s piletinom, slatkim koumpirom i biljem.\r\n\r\nProDen PlaqueOff formulisan je iz posebnih morskih algi koje rastu uz obalu Severnog Atlantika. Deluje putem krvotoka oslobađajući prirodni spoj putem sline koji rastvara bakterijski film na gleđi zuba gde se stvara plak. Posebna veličina i oblik granula pomaže održati zube čistima.\r\n\r\nSASTAV: sveže pripremljena otkošćena ćuretina 26%, sušena p', 'images/proizvodi/sesn.jpg'),
(21, 'RUSTICAN Ćuretina i zečetina s tikvicama i krompirom, bez glutena', 209, 11, 'RUSTICAN Turkey and rabbit with zucchini and potatoes\r\nGreat food, great life!\r\n\r\nRUSTICAN Ćuretina i zečetina sa tikvicama i krompirom, potpuna hrana za odrasle pse.\r\nBez glutena.\r\n\r\nSastojci: meso i mesne prerađevine (ćuretina 40%, zečetina 25%), povrće (tikvice 3%, krompir 2%), minerali 1%, ulja i masti (laneno ulje 0,1%).\r\n\r\nAnalitički sastav: proteini 10,7%, sadržaj masti 6,8%, sirovi pepeo 2,5%, sirova vlakna 0,5%, vlaga 75%.\r\n\r\nNutritivni dodaci/kg: vitamin D3 200 IJ, cink (cink sulfat mo', 'images/proizvodi/sedamn.jpg'),
(22, 'CARNILOVE PUPPY Losos i ćuretina, bez žitarica', 1050, 13, 'CARNILOVE Puppy Salmon & Turkey\r\nPotpuna hrana za štenad svih rasa, starosti od 1 do 12 meseci, s lososom i ćuretinom.\r\n70% mesa poreklom iz divljine, 30% šumskog voća, povrća i bilja.\r\nHrana bez žitarica i krompira\r\n\r\nLosos je dobar izvor visoko svarljivih proteina. Lako se vari i ima anti-inflamatorna svojstva. Obilje omega-3 nezasićenih masnih kiselina ima pozitivan uticaj na mentalni razvoj, kardiovaskularni sistem i metabolizam (smanjuju nivo šećera u krvi). Poboljšava kvalitet i izgled dla', 'images/proizvodi/osamn.jpg'),
(23, 'SCHESIR Konzerva za pse s piletinom i ananasom 150g', 239, 10, 'SCHESIR Konzerva za pse s piletinom i ananasom\r\nDopunska hrana za odrasle pse\r\n\r\nSASTOJCI: piletina min. 40%, ananas min. 4,1%, pirinač 2%, biljni žele (dozvoljen po EU).\r\n\r\nANALITIČKI SASTAV: vlaga 84%, sirovi proteini 11%, sirovi pepeo 1,5%, sirove masti 0,2%, sirova vlakna 0,1%.\r\n\r\nNivo vitamina zagarantovan je do isteka roka upotrebe.\r\nProizvedeno po proizvođačkoj specifikaciji.\r\n\r\nUPUTSTVO ZA HRANJENJE:\r\nJedna konzerva dnevno, uz ostale Schesir proizvode, zadovoljavaju dnevne potrebe odrasl', 'images/proizvodi/devetn.jpg'),
(24, 'WOLFPACK Black Angus govedina, hladno presovana hrana za pse', 1390, 15, 'WOLFPACK Hladno presovana hrana s govedinom Black Angus - najbolje iz prirode!\r\nPotpuna hrana za pse svih uzrasta i rasa\r\n\r\nZasnovana na principima ishrane pasa i vukova kao što je u njihovom prirodnom staništu, gde odrasli dele svoj obrok sa mladuncima.\r\n\r\nŠta je proces hladnog presovanja?\r\nNakon mešanja, fino samleveni sastojci presovanjem se oblikuju u pelete bez podvrgavanja visokim temperaturama.\r\nNiska temperatura obezbeđuje očuvanje osnovnih hranljivih materija, posebno onih koji u sebi s', 'images/proizvodi/dvad.jpg'),
(25, 'ADVANTIX® (Bayer) Ampula SpotOn za pse protiv buva i krpelja', 790, 15, 'ADVANTIX® (Bayer) - Spot-on ampula protiv buva i krpelja za pse\r\n\r\nAdvantix® Spot-on - Rastvor za nakapavanje na kožu, antiparazitik, ektoparaziticid, kombinacija imidakloprida i permetrina\r\no za pse preko do 4 kg - Advantix® 40 mg (0,4 ml) Spot-on\r\no za pse od 4 do10 kg - Advantix® 100 mg (1,0 ml) Spot-on\r\no za pse od 10 do 25 kg - Advantix® 250 mg (2,5 ml) Spot-on\r\no za pse od 25 do 40 kg - Advantix® 400 mg (4,0 ml) Spot-on\r\no za pse preko 40 kg - Advantix® 600 mg (4,0 ml) Spot-on\r\n\r\nIndikacij', ' images/proizvodi/dvadj.jpg'),
(32, 'BRIT PREMIUM by Nature, mesna pašteta za pse s ribom i ribljom kožom', 159, 14, 'Brit Premium by Nature Fish with Fish Skin.\r\n\r\nMesna pašteta s ribljom kožom za pse.\r\n\r\nIdealan dodatak granulama. Potpuna hrana, poslastica ili dodatak okusu granula za odrasle pse svih rasa.\r\n\r\nPomaže u poboljšanju unosa hrane i dopunjavanja tekućine. Sadrži kolagen za podršku zdravih zglobova, lososovo ulje, voće i biljke.\r\n- Odlična svarljivost i odličan okus\r\n- Izbalansirana količina nutrijenata, vitamina i minerala\r\n- Bez ŽITARICA - bez SOLI - bez GMO\r\n\r\nSastav: riba 36 %, riblji bujon 35,', 'images/proizvodi/dvadd.jpg'),
(33, 'WHISKAS Poslastica za mačke Trio Crunchy Živina, 55g', 99, 15, 'WHISKAS® Trio Crunchy\r\n\r\nDodatna hrana za odrasle mačke s ukusom piletine, ćuretine i pačetine\r\n\r\nSASTOJCI: žitarice, proizvodi biljnog porekla, meso i proizvodi životinjskog porekla (uključujući 1% pačetine, 1% ćuretine, 12.7% sušene živinske džigerice u prahu, ekvivalentno 22.2% piletine), ekstrakti biljnih proteina, ulja i masti, minerali, kvasci.\r\n\r\nANALITIČKI SASTAV (%): proteini: 36.0; sadržaj masti: 9.0; neorganska materija: 9.3; sirova vlakna: 2.0; omega 6 masne kiseline: 8286 mg/kg; ene', 'images/proizvodi/dvadt.jpg'),
(34, 'MYFAMILY Ogrlica za pse, kožna Tucson', 3890, 12, 'Ogrlica za pse', 'images/proizvodi/dvadc.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `type`) VALUES
(18, 'Nikolina', 'n1na@gmail.com', NULL, '$2y$10$gW3zNCvHqoENIyTG8kfcm.JHbLT.XFGpZtpTGKmGuyU.OvbaqGS1m', NULL, '2021-07-13 06:22:10', '2021-07-13 06:22:10', 'editor'),
(21, 'admin', 'admin@gmail.com', NULL, '$2y$10$/P3euDRtMfBYk.CVKHP0buOCBgCnSam6MwrfvFdXH8rqeRHXEI3Py', NULL, '2021-07-13 06:22:10', '2021-07-13 06:22:10', 'admin'),
(23, 'Nikola', 'nikola@gmail.com', NULL, '$2y$10$1u03GsVjbTCb4os0vG6WluxEghWP7fuM9GoZ0NpFDXVRnji8swGtO', NULL, '2021-07-07 12:40:31', '2021-07-07 12:40:31', 'user'),
(25, 'Ninaa', 'nina@gmail.com', NULL, '$2y$10$UDikAAxYTYZ.IxqOKf/2C.3SH0qdoIs2dUEUiYiqz5iqW7F7kqbZW', NULL, '2021-07-13 06:22:10', '2021-07-13 06:22:10', 'user'),
(27, 'ivica', 'i@gmail.com', NULL, '$2y$10$fplryxI99HlAF4NpMbPe1.x7Toyt50jc0nbKbsRrcRMNyJTM3EHnu', NULL, '2021-07-14 04:38:19', '2021-07-14 04:38:19', 'user'),
(28, 'mrkii', 'm@gmail.com', NULL, '$2y$10$uPCPkdNBiuDeElMJzhvLc.5UTd13aLzMh1SeF6J0oC5sIm36PiZMq', NULL, '2021-07-14 05:05:57', '2021-07-14 05:05:57', 'user'),
(29, 'jocaaa', 'j@gmail.com', NULL, '$2y$10$YiJU.TfIoAtFahRL/C2jMuArS81iGmkkgm9BhRNpp.NMXscAb4QnO', NULL, '2021-07-14 05:32:26', '2021-07-14 05:32:26', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`likeID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `likeID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="container c-login">
    <form action="<?php echo e(route('register')); ?>" method="POST" class="form-signin">
        <?php echo csrf_field(); ?>

        <div>
            <i class="fas fa-spa"></i>
            <h1 class="h3 mb-3 font-weight-normal">Register</h1>
        </div>

        <div>
            <input 
                type="text" 
                name="username"
                class="form-control" placeholder="Username"
                value="<?php echo e(old('username')); ?>"
                autofocus
            >
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input 
                type="email" 
                name="email" 
                class="form-control" placeholder="Email"
                value="<?php echo e(old('email')); ?>"
            >
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input 
                type="password" 
                name="password" class="form-control" placeholder="Password"
            >
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input 
                type="password" name="password_confirmation" class="form-control" placeholder="Repeat password"
            >
        </div>
        <button class="btn btn-lg btn-block mt-4" type="submit">Register</button>

        <a href="">
            <p class="">Back to Login page</p>
        </a>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/register.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="<?php echo e(asset('css/user.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row">

        <div class="user-info col-lg-12">
            <?php if($user->type == 'admin'): ?>
                <h1>Admin: <?php echo e($user->username); ?></h1>
            <?php elseif($user->type == 'editor'): ?>
                <h1>Editor: <?php echo e($user->username); ?></h1>
            <?php else: ?>
                <h1>Username: <?php echo e($user->username); ?></h1>
            <?php endif; ?>
            <p>Email: <?php echo e($user->email); ?></p>
            

            <a class="edit-user-icon" href="<?php echo e(route('editUser', ['id' => $user->userID])); ?>">
                <i class="fas fa-edit mb-4"></i>
            </a>
        </div>

    </div>
    
    

            <div class="container nesto1">
                <div class="row">
                    <div>
                        <table>
                            <tr>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Kolicina</td>
                                <td class="nesto">Cena</td>
                            </tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($o->naziv); ?></p></td>
                                <td class="nesto"><p><?php echo e($o->amount); ?></p></td>
                                <td class="nesto"><p><?php echo e($o->amount * $o->cena); ?></p></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
</div>
            

<script src="js/adminSearch.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/user.blade.php ENDPATH**/ ?>
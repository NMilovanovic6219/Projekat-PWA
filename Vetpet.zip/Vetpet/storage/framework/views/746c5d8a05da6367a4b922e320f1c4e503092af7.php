<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="container c-login">
    <form action="<?php echo e(route('login')); ?>" method="POST" class="form-signin">
        <?php echo csrf_field(); ?>

        <?php if(session('loginErr')): ?>
            <p class="loginErr" style="color: #FF5145"><?php echo e(session('loginErr')); ?></p>
        <?php endif; ?>


        <div>
            <input type="text" class="form-control" placeholder="Username"
            name="username" autofocus>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" class="form-control" placeholder="Password"
            name="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
       
        <button type="submit">Uloguj se</button>
       
    </form>
</div>

<script>
    setTimeout(() => {
        document.querySelector('.loginErr').style.display = 'none'
    }, 3000)
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/login.blade.php ENDPATH**/ ?>
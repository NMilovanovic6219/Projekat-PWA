<link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">

<?php $__env->startSection('content'); ?>

<section class="section pb-5">

  
    <div class="row">
  
      <div class="col-lg-5 mb-4">

        <form action="" method="POST">
          <?php echo csrf_field(); ?>
          <div class="card">
  
            <div class="card-body">
              <div class="form-header blue accent-1">
                <h3> Pisite nam:</h3>
              </div>
    
              
              <br>

              <div class="md-form">
                 
                  <input type="text" class="form-control" placeholder="Vase ime" name="ime" value="<?php echo e(old('ime')); ?>">
              </div>
              <?php $__errorArgs = ['ime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
              <div class="md-form">
                
                <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
              </div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
              <div class="md-form">
                
                <input type="text" class="form-control" placeholder="Naslov poruke" name="naslov" value="<?php echo e(old('naslov')); ?>">
              </div>
              <?php $__errorArgs = ['naslov'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
              <div class="md-form">
                
                <textarea name="tekst" class="form-control md-textarea" rows="3" placeholder="Tekst poruke" value="<?php echo e(old('tekst')); ?>"></textarea>
              </div>
              <?php $__errorArgs = ['tekst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
              <div class="text-center mt-4">
                <button type="submit" class="btn submit">Posalji</button>
              </div>
            </div>
    
          </div>
        </form>
  
      </div>

      
  
    </div>
  
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vetpet\resources\views/pages/contact.blade.php ENDPATH**/ ?>
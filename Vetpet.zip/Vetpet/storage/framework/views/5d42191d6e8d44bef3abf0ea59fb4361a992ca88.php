<link rel="stylesheet" href="<?php echo e(asset('css/product-edit.css')); ?>">

<?php $__env->startSection('content'); ?>

    <h1>
        
        <?php echo e($product->naziv); ?>

    </h1>

<div class="container">
    <div class="row">
        <form class="m-5 form" action="" method="POST">
            <?php echo csrf_field(); ?>

            <input name="id" type="hidden" value="<?php echo e($product->productID); ?>">

            <label>
                <p style="margin: 0 !important">Naziv:</p>
                
                <input name="naziv" type="text" value="<?php echo e($product->naziv); ?>">
            </label>

            <label>
                <p style="margin: 0 !important">Cena:</p>
                
                <input name="cena" type="number" value="<?php echo e($product->cena); ?>">
            </label>

            
            <label>
                <p style="margin: 0 !important">Na stanju:</p>
                
                <input name="naStanju" type="number" value="<?php echo e($product->naStanju); ?>">
            </label>

            <label>
                <p style="margin: 0 !important">Slika proizvoda:</p>
                
                <input name="img" type="text" value="<?php echo e($product->img); ?>">
            </label>

                
            <textarea name="opis" rows="10" cols="50" class="p-3"><?php echo e($product->opis); ?></textarea>

            <button class="mt-3" type="submit">Izmeni</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vetpet\resources\views/pages/editProduct.blade.php ENDPATH**/ ?>
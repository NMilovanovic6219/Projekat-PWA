<link rel="stylesheet" href="<?php echo e(asset('css/user-edit.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="user-edit-header">
    <h1>
        Editing user: 
        <?php echo e($user->username); ?>

    </h1>
</div>

<div class="container">
    <div class="row">
        <form class="m-5 form" action="" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <i class="fas fa-user"></i>
            </div>

            <input name="id" type="hidden" value="<?php echo e($user->userID); ?>">

            <label>
                <p style="margin: 0 !important">Password:</p>
                
                <input name="password" type="password" value="<?php echo e($user->password); ?>">
            </label>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #FF5145"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label>
                <p style="margin: 0 !important">Confirm:</p>
                
                <input 
                type="password" name="password_confirmation" class="form-control" value="<?php echo e($user->password); ?>">
            </label>

            <?php if(auth()->user()->type === 'admin'): ?>
                <select name="type" class="form-control">
                    <?php if($user->type == 'user'): ?>
                        <option value="user">User</option>
                        <option value="editor">Editor</option>
                        <option value="admin">Admin</option>
                    <?php elseif($user->type == 'editor'): ?>
                        <option value="editor">Editor</option>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    <?php else: ?>
                        <option value="admin">Admin</option>
                        <option value="editor">Editor</option>
                        <option value="user">User</option>
                    <?php endif; ?>
                </select>
            <?php endif; ?>

            <button class="mt-3" type="submit">Submit</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/editUser.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo/logo1.jpg')); ?>" type="image/x-icon">  

    <title>Vetpet</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

</head>
<body>
  <header>
      <nav class="navbar navbar-expand-md navbar-dark" style="width: 100%">
       
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo e(route('homepage')); ?>">Početna</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('store')); ?>">Proizvodi</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('about')); ?>">O name</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('contact')); ?>">Kontakt</a>
            </li>
            <?php if(auth()->user()): ?>
              <?php if(auth()->user()->type === 'admin' || auth()->user()->type === 'editor'): ?>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
              <?php endif; ?>
            <?php endif; ?>
          </ul>
          <div class="buttons">
            <?php if( auth()->user() ): ?>
              <a href="<?php echo e(route('user')); ?>">
                <button id="user" type="button" class="btn ml-1">
                  <?php echo e(auth()->user()->username); ?>

                </button>
              </a>

              <form class="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn ml-1">Izloguj se</button>
              </form>
            <?php else: ?>
              <!-- <a href="<?php echo e(route('login')); ?>">
                <button type="button" class="btn ml-1">Uloguj se</button>
              </a> -->
              <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Uloguj se</button>

                <div id="id01" class="modal">
                  
                  <form class="modal-content animate" action="<?php echo e(route('login')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div class="imgcontainer">
                      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    
                    </div>

                    <div class="container">
                      <input type="text" class="form-control" placeholder="Username"
                        name="username" autofocus>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color: rad"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <input type="password" class="form-control" placeholder="Password"
                        name="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color: rad"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>      
                              
                     <button type="submit">Uloguj se</button>
                    </div>

                    
                  </form>
                </div>







              <button onclick="document.getElementById('id02').style.display='block'" style="width:auto;">Registruj se</button>

                <div id="id02" class="modal">
                  
                  <form class="modal-content animate" action="<?php echo e(route('register')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div class="imgcontainer">
                      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    
                    </div>

                              <div class="container">
                                <input 
                          type="text" 
                          name="username"
                          class="form-control" placeholder="Username"
                          value="<?php echo e(old('username')); ?>"
                          autofocus
                      >
                      <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <p style="color: #FF5145"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <input 
                          type="email" 
                          name="email" 
                          class="form-control" placeholder="Email"
                          value="<?php echo e(old('email')); ?>"
                      >
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <p style="color: #FF5145"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <input 
                          type="password" 
                          name="password" class="form-control" placeholder="Password"
                      >
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <p style="color: #FF5145"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      <input 
                          type="password" name="password_confirmation" class="form-control" placeholder="Repeat password"
                      >
                              
                     <button type="submit">Registruj se</button>
                    </div>

                    
                  </form>
                </div>
            <?php endif; ?>
          </div>
        </div>
      </nav>
    </header>

    
      <?php echo $__env->yieldContent('content'); ?>


      <div class="to-top">
        <a href="#top">
          <i class="fas fa-arrow-circle-up"></i>
        </a>
      </div>
    <footer class="footer-about text-center text-lg-start">
        <!-- Copyright -->
        <div class="text-center p-3">
          Nesto
          
        </div>
        <!-- Copyright -->
    </footer>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/layouts/layout.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="cover">
    <div class="inner">
        
    </div>
</div>

<div class="row section-1" style="width: 100%">
    <div class="row-inner col-lg-4">
        
        <h3>BESPLATNA DOSTAVA</h3>
        <p>za porudžbine iznad 3.000 din</p>
    </div>
    <div class="row-inner col-lg-4">
        
        <h3>IMATE LI PROMO KOD?</h3>
        <p>Klinite ovde unesite promo kod i ostvarite popust!</p>
    </div>
    <div class="row-inner col-lg-4">
        
        <h3>KONTAKTIRAJTE NAS</h3>
        <p>011 2123 305</p>
    </div>
</div>


<div class="row gallery col-lg-12">
    <div class="col-lg-4 col-md-4">
      <img class="prva" src="images/homepage/gallery/prva.jpg" alt=""/>
      </div>
      <div class="col-lg-4 col-md-4">
      <img class="prva" src="images/homepage/gallery/druga.jpg" alt=""/>
</div>

      <div class="col-lg-4 col-md-4">
      <img class="prva" src="images/homepage/gallery/treca.jpg" alt="" />
      </div>   
</div>


<div class="row section-2" style="width: 100%">
    <div class="row-inner-2 col-lg-6 col-sm-12">
        <h4>Prodavnice
        </h4>
        <p>Novi Beograd - Bulevar M. Milankovića 1v</p>
        <p>Novi Beograd - Bulevar M. Milankovića 1v</p>
        <p>Novi Beograd - Bulevar M. Milankovića 1v</p>
    </div>
    <div class="row-inner-2 col-lg-6 col-sm-12">
        <h4>Pet centar</h4>
        <ul>
            <li>
                <a href="<?php echo e(route('about')); ?>">
                    O nama
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('store')); ?>">
                    Prodavnica
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('contact')); ?>">
                    Kontakt
                </a>
            </li>
        </ul>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/homepage.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="header-product">
    <a href="<?php echo e(route('store')); ?>">
        <i class="fas fa-arrow-left"></i>
    </a>
    <h1 class="text-center"><?php echo e($p->naziv); ?></h1>
</div>
<div class="container c-product">
    <section class="py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
                <div class="col-md-6">
                    <img style="border-radius: 15px; border: 1px solid #ddd;" class="card-img-top mb-5 mb-md-0" src="<?php echo e(asset($p->img)); ?>" alt="..." />
                </div>
                <div class="col-md-6">
                    <div class="fs-5 mb-5">
                        <p style="margin-bottom: 0;">Cena: <?php echo e($p->cena); ?> din</p>
                        <p>Dimenzije: <?php echo e($p->dimenzije); ?></p>
                    </div>
                    <p class="lead"><?php echo e($p->opis); ?></p>
                    <?php if($p->naStanju == 0): ?>
                        <p class="lead">Nema na stanju</p>
                    <?php else: ?>
                        <p class="lead">Na stanju: <?php echo e($p->naStanju); ?></p>
                        <div class="d-flex align-items-center">
                            <form class="d-flex align-items-center" action="<?php echo e(route('addOrder')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <input name="amount" class="form-control text-center me-3" type="num" value="1" style="max-width: 3rem" />

                                <input type="hidden" name="userID" value="<?php echo e(auth()->user()->userID); ?>">

                                <input type="hidden" name="productID" value="<?php echo e($p->productID); ?>">

                                <button type="submit" class="product-btn btn btn-outline-dark flex-shrink-0" type="button">
                                    Dodaj u korpu
                                </button>
                            </form>

                            <div class="ml-3" style="display: inline-block">
                                <form class="likes" action="<?php echo e(route('addLike')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="userID" value="<?php echo e(auth()->user()->userID); ?>">
                                    <input type="hidden" name="productID" value="<?php echo e($p->productID); ?>">

                                    <button type="submit">
                                        <i style="color: #FF5145;" class="far fa-heart"></i>
                                    </button>
                                    
                                    <span><?php echo e(count($likes)); ?></span>
                                </form>
                                
                            </div>
                        </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </section>

    <div class="container mt-5">
        <div class="d-flex justify-content-center row">
            <div class="col-md-12">
                <div class="d-flex flex-column comment-section">
                    <div class="bg-light pt-2 mb-4">
                        <form action="<?php echo e(route('addComment')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="productID" value="<?php echo e($p->productID); ?>">

                            <input type="hidden" name="userID" value="<?php echo e(auth()->user()->userID); ?>">

                            <div class="d-flex flex-row align-items-start">
                                <textarea name="tekst" id="comment-body" class="form-control shadow-none textarea" placeholder="Write a comment.."></textarea>
                            </div>
                            <div class="mt-2 text-right">
                                <button class="submit-btn product-btn btn btn-primary btn-sm shadow-none" type="submit">Post comment</button>
                                <button class="cancel-button product-btn btn btn-outline-primary btn-sm ml-1 shadow-none" type="button">Cancel</button>
                            </div>
                        </form>
                    </div>

                    <div class="comments-container">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="comment" class="bg-white p-4 mb-2" style="border: 1px solid #e2e2e2; border-radius: 10px;">
                                <div class="d-flex flex-row user-info">
                                    <i class="fas fa-user comment-icon"></i>
                                    <div class="d-flex flex-column justify-content-start ml-2"><span class="d-block font-weight-bold name"><?php echo e($c->username); ?></span><span class="date text-black-50">Kreirano: <?php echo e($c->created_at); ?></span></div>
                                </div>
                                <div class="mt-2">
                                    <p class="comment-text"><?php echo e($c->tekst); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>


</div>

<script type="text/javascript">

    const productButton = document.querySelector('.product-btn')
    productButton.addEventListener('click', (e) => {
        if(!confirm('Potvrdi kupovinu!')) {
            e.preventDefault()
        }    
    })

</script>
<script src="<?php echo e(asset('js/product.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Flowershop-App-master\resources\views/pages/product.blade.php ENDPATH**/ ?>
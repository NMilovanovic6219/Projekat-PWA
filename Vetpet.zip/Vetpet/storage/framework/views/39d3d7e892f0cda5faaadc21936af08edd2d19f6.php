<link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">

<?php $__env->startSection('content'); ?>



<div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Korisnici</h1>
                        <table>
                            <tr>
                                <td class="nesto">Username</td>
                                <td class="nesto">Email</td>
                                <td class="nesto">Tip</td>
                                <td class="nesto">Created at:</td>
                                <td class="nesto">Updated at:</td>
                            </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($u->username); ?></p></td>
                                <td class="nesto"><p><?php echo e($u->email); ?></p></td>
                                <td class="nesto"><p><?php echo e($u->type); ?></p></td>
                                <td class="nesto"><p><?php echo e($u->created_at); ?></p></td>
                                <td class="nesto"><p><?php echo e($u->updated_at); ?></p>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                <div class="u-icons">
                                    <a href="<?php echo e(route('editUser', [
                                        'id' => $u->userID
                                    ])); ?>">
                                        <p>Edituj</p>
                                    </a>

                                    <a href="<?php echo e(route('deleteUser', [
                                        
                                        'id' => $u->userID
                                    ])); ?>">
                                        <p>Obriši</p>
                                    </a>
                            
                                </div>
                            <?php endif; ?>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>

                           
                              
                        </div>
                    
                
            </div>
            </div> 
            </div>
            </div>
           
            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Proizvodi</h1>
                        <table>
                            <tr>
                                <td class="nesto">Naziv</td>
                                <td class="nesto">Cena</td>
                                <td class="nesto">Na stanju</td>
                                <td class="nesto">Opis</td>
                                
                            </tr>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($p->naziv); ?></p></td>
                                <td class="nesto"><p><?php echo e($p->cena); ?></p></td>
                                <td class="nesto"><p><?php echo e($p->naStanju); ?></p></td>
                                <td class="nesto"><p><?php echo e($p->opis); ?></p>
                                <div class="p-icons">
                                <a href="<?php echo e(route('editProduct', [
                                    'id' => $p->productID
                                ])); ?>">
                                    <p>Edituj</p>
                                </a>
                                
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a href="<?php echo e(route('deleteProduct', [
                                        'id' => $p->productID
                                    ])); ?>">
                                    <p>Obriši</p>
                                    </a>
                                <?php endif; ?></td>
                                
                                
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div>   
            </div>
            </div>                          


            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Poridzbine</h1>
                        <table>
                            <tr>
                                <td class="nesto">Username</td>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Cena</td>
                                
                            </tr>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($o->username); ?></p></td>
                                <td class="nesto"><p><?php echo e($o->amount); ?></p></td>
                                <td class="nesto"><p><?php echo e($o->amount * $o->cena); ?></p>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                        <a href="<?php echo e(route('deleteOrder', ['id' => $o->orderID])); ?>">
                                            <p>Obrisi</p>
                                        </a>
                                    <?php endif; ?></td>
                                
                                
                                
                            </tr>
                            
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>





            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Poruke</h1>
                        <table>
                            <tr>
                                <td class="nesto">Naslov</td>
                                <td class="nesto">Status</td>
                                <td class="nesto">Ime</td>
                                <td class="nesto">Email</td>
                                <td class="nesto">Poruka</td>
                                
                            </tr>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($m->naslov); ?></p></td>
                                <td class="nesto"><p><?php echo e($m->status); ?></p></td>
                                <td class="nesto"><p><?php echo e($m->ime); ?></p></td>
                                <td class="nesto"><p><?php echo e($m->email); ?></p></td>
                                <td class="nesto"><p><?php echo e($m->tekst); ?></p> 
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a href="<?php echo e(route('deleteMessage', ['id' => $m->messageID])); ?>">
                                        <p>Obriši</p>
                                    </a>
                                <?php endif; ?>    
                            </td>
                                
                            </tr>
                            
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>



            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Srca</h1>
                        <table>
                            <tr>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Korisnik</td>
                                
                            </tr>
                            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($l->naziv); ?></p></td>
                                <td class="nesto"><p><?php echo e($l->username); ?></p>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a href="<?php echo e(route('deleteLike', ['id' => $l->likeID])); ?>">
                                    <p>Obriši</p>
                                    </a>
                                <?php endif; ?>
                            </td>
                                
                                
                            </tr>
                            
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>



            <div>
    <div class="container mt-5">
        <div class="row mb-3">
           
                

                <div class="ac-bottom">
                    
                        <div class="u p-4 mb-2">
                            

                            <div>
                                <h1>Komentari</h1>
                        <table>
                            <tr>
                                <td class="nesto">Korisnik</td>
                                <td class="nesto">Proizvod</td>
                                <td class="nesto">Tekst</td>
                                
                            </tr>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td class="nesto"><p class="order-name-user"><?php echo e($c->username); ?></p></td>
                                <td class="nesto"><p><?php echo e($c->naziv); ?></p></td>
                                <td class="nesto"><p><?php echo e($c->tekst); ?></p>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a href="<?php echo e(route('deleteComment', ['id' => $c->commentID])); ?>">
                                    <p>Obriši</p>
                                    </a>
                                <?php endif; ?>
                            </td>
                               
                            
                                
                                
                            </tr>
                            
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>

                            
                              
                        </div>
                    
                
            </div> 
            </div> 
            </div>
            </div>

           




    

        <div class="row">
            <div class="col" id="chart_div"></div>
        </div>
    </div>
</div>



<script src="js/adminSearch.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    const chartInfo = <?php echo json_encode($orders->toArray()); ?>


    const productsArr = []
    const newArr = []

    chartInfo.forEach(el => {
        productsArr.push([el.naziv, el.amount])
        newArr.push(el.naziv)
    })

    let s = new Set(newArr);
    let setValues = Array.from(s.values());

    const arr = []
    for(let i = 0; i < setValues.length; i++) {
        let num = 0

        for(let j = 0; j < productsArr.length; j++) {
            if(productsArr[j][0] === setValues[i]) {
                num += productsArr[j][1]
                
                productsArr.splice(j, 1)
            }
        }

        arr.push([setValues[i], num])
    }

    // Load the Visualization API and the corechart package.
    google.charts.load('current', {'packages':['corechart']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawChart);

    // Callback that creates and populates a data table,
    // instantiates the pie chart, passes in the data and
    // draws it.
    function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', '');
        data.addRows(arr);

        const height = data.getNumberOfRows() * 81 + 30;
        // Set chart options
        var options = {'title':'Sold Products',
                        'width': '100%',
                        'height': height};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(data, options);
    }
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vetpet\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>
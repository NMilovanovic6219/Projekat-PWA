<link rel="stylesheet" href="<?php echo e(asset('css/store.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-lg-3 col-md-6 text-center" >
                <img class="card-img-top" src="<?php echo e($p->img); ?>" alt="Nije do nas">
                <div class="card-body">
                  <h4 class="card-title"><?php echo e($p->naziv); ?></h4>
                  <p class="card-text">Cena: <?php echo e($p->cena); ?>din</p>
                  <a href="<?php echo e(route('product', ['id' => $p->productID])); ?>" 
                  class="s-product-btn btn btn-primary">Vidi proizvod</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vetpet\resources\views/pages/store.blade.php ENDPATH**/ ?>